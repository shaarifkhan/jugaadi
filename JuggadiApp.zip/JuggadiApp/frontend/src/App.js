import React, { Component } from 'react';
import './App.css';
import Home from './components/Jhome/Jhome';
import Signin from './components/Auth/Signin';
import Signup from './components/Auth/Signup';
import Dashboard from './components/Dashboard/Dashboard';
import Fhome from './components/Jhome/Fhome'
import Post from './components/functions/Post';
import Want from './components/functions/Want';
import Ride from './components/functions/ride';
import Wallet from './components/functions/Payment';
import Info from './components/functions/Info';
import { BrowserRouter,Switch,Route} from 'react-router-dom';
class App extends Component {
  render() {
     //<AuthContext.Provider value={false}></AuthContext.Provider>
    return (
      <BrowserRouter>
      <div className="App">
        <Switch> 
        <Route exact path='/dashboard' component={Dashboard}></Route>
          <Route exact path= '/' component={Home}/>
          <Route exact path= '/Signin' component={Signin}/>
          <Route exact path= '/Signup' component={Signup}/>
          <Route exact path='/post' component={Post}></Route>
          <Route exact path='/want' component={Want}></Route>
          <Route exact path='/fhome' component={Fhome}></Route>
          <Route exact path='/ride' component={Ride}></Route>
          <Route exact path='/wallet' component={Wallet}></Route>
          <Route exact path='/info' component={Info}></Route>

        </Switch>
      </div>
      </BrowserRouter>
    );
  }
}

export default App;
