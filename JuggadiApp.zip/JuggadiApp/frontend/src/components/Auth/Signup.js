import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';
import { white } from 'material-ui/styles/colors';
import axios from 'axios';
import {Redirect} from 'react-router-dom';
import Navbar from './../layout/Navbar';

class Register extends Component {
  constructor(props){
    super(props);
    this.state={
      name:'',
      email:'',
      password:'',
      mobileNo:'',
      cnic:'',
      address:''
    }
  }
  handleClick(){
    console.log(this.state)

  }
  register=()=>{
    console.log(this.state);
  axios.post('http://192.168.100.16:4000/register',this.state)
  .then(res=>{console.log(res)
  this.props.history.push('/email')
  })}
  render() {
    return (
      
      <div>
        <Navbar/>
        <MuiThemeProvider>
        <AppBar
      
             title="Sign Up For Free!"
           />
          <div className="container">
           <br></br>
           <br></br>
           <br></br>
           
           <TextField floatingLabelStyle={{color: white}}  hintStyle={{color: white}} inputStyle={{color: white}}
             hintText="Enter your Name"
             floatingLabelText="Name"
             onChange = {(event,newValue) => this.setState({name:newValue})}
             />
             <br/>
           <TextField floatingLabelStyle={{color: white}}  hintStyle={{color: white}} inputStyle={{color: white}}
             hintText="Enter your Email"
             type="email"
             floatingLabelText="Email"
             onChange = {(event,newValue) => this.setState({email:newValue})}
             />
           <br/>
           <TextField floatingLabelStyle={{color: white}}  hintStyle={{color: white}} inputStyle={{color: white}}
             type = "password"
             hintText="Enter your Password"
             floatingLabelText="Password"
             onChange = {(event,newValue) => this.setState({password:newValue})}
             />
           <br/>
           <TextField floatingLabelStyle={{color: white}}  hintStyle={{color: white}} inputStyle={{color: white}}
             type = "number"
             hintText="Enter your Contact Number"
             floatingLabelText="Contact Number"
             onChange = {(event,newValue) => this.setState({number:newValue})}
             />
           <br/>
           <TextField floatingLabelStyle={{color: white}}  hintStyle={{color: white}} inputStyle={{color: white}}
             type = "Number"
             hintText="Enter your CNIC"
             floatingLabelText="CNIC"
             onChange = {(event,newValue) => this.setState({CNIC:newValue})}
             />
           <br/>
           <TextField floatingLabelStyle={{color: white}}  hintStyle={{color: white}} inputStyle={{color: white}}
             type = "text"
             hintText="Enter your Address"
             floatingLabelText="Address"
             onChange = {(event,newValue) => this.setState({Address:newValue})}
             />
           <br/>
           <RaisedButton label="Sign up" primary={true} style={style} onClick={(event) => this.register(event)}/>
          </div>
         </MuiThemeProvider>
      </div>
    );
  }
}
const style = {
  margin: 15,

  'inputLabel': {
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    width: '100%',
    color: 'red'
  },
  
  'input': {
    '&::placeholder': {
      textOverflow: 'ellipsis !important',
      color: 'blue'
    }
  }
};
export default Register;