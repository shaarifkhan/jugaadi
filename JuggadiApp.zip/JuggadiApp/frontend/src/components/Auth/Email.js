import React, { Component } from 'react';
import Navbar from './../layout/Navbar';
handleclick=()=>{

}
class Email extends Component{
    render(){
    return(
        <div>
        <Navbar/>
        <div className="container-home">
            Please Verify Your Email
        </div>
        <div className="col-md-12">
  <input onClick={this.handleclick} type="submit" value="Post"  className="btn btn-primary  py-2 px-5" style={{backgroundColor:'#00BCD4'}}/>
        </div>
        </div>
    )
}
}
export default Email;