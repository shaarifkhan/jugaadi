import React,{ useState } from 'react';
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
// core components
import GridItem from "./../Grid/GridItem.js";
import GridContainer from "./../Grid/GridContainer";
import CustomInput from "./../CustomInput/CustomInput";
import Button from "./../CustomButtons/Button";
import Card from "./../Card/Card";
import CardHeader from "./../Card/CardHeader.js";
import CardAvatar from "./../Card/CardAvatar.js";
import CardBody from "./../Card/CardBody.js";
import CardFooter from "./../Card/CardFooter.js";
import './hello.css';
import Dashbar from './../layout/Dashbar';
import {Redirect} from 'react-router-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import TextField from 'material-ui/TextField';
import { white } from 'material-ui/styles/colors';
import avatar from './../../assets/img/faces/FawazAnsari.jpg';
const style = {
  margin: 15,

  'inputLabel': {
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    width: '100%',
    color: 'red'
  },
  
  'input': {
    '&::placeholder': {
      textOverflow: 'ellipsis !important',
      color: 'blue'
    }
  }
};
const styles = {
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none"
  }
};

const useStyles = makeStyles(styles);

export default function UserProfile() {
  const classes = useStyles();
  const [fname,setFname] = useState("Fawaz");
  const [lname,setLname] = useState("Ansari");
	const [email,setEmail] = useState("fawazransari@gmail.com");
  const [contact,setContact] = useState("0331-0350398");
  const [cnic,setCnic] = useState("42101-1097794-7");
  const [address,setAddress] = useState("Karachi");
  const state={fname,lname,email,contact,cnic,address}
	const handleclick=()=>{
    console.log(state)
  }
  return (
    <div >
      <br/><br/>
      <GridContainer>
        <GridItem xs={12} sm={12} md={8}>
          <Card>
            <CardHeader >
              <h4 className={classes.cardTitleWhite}>Edit Profile</h4>
              <p className={classes.cardCategoryWhite}>Complete your profile</p>
            </CardHeader>
            <CardBody>
            <MuiThemeProvider>
              <GridContainer>
                <GridItem xs={12} sm={12} md={4}>
                <TextField 
                hintText="First Name"
                floatingLabelText="First Name"
                value={fname}
                onChange={e => setFname(e.target.value)}
                />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                <TextField 
                hintText="Last Name"
                floatingLabelText="Last Name"
                value={lname}
                onChange={e => setLname(e.target.value)}
                />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                <TextField 
                hintText="Email"
                floatingLabelText="Email"
                value={email}
                onChange={e => setEmail(e.target.value)}
             />
                </GridItem>
                </GridContainer>
                <br/>
                <GridContainer>
                  <GridItem xs={12} sm={12} md={4}>
                  <TextField 
                hintText="Contact No"
                floatingLabelText="Contact No"
                value={contact}
                onChange={e => setContact(e.target.value)}
             />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                <TextField 
                hintText="CNIC"
                floatingLabelText="CNIC"
                value={cnic}
                onChange={e => setCnic(e.target.value)}
             />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                <TextField 
                hintText="Address"
                floatingLabelText="Address"
                value={address}
                onChange={e => setAddress(e.target.value)}
             />
                </GridItem>
              </GridContainer>
              <br/>
              </MuiThemeProvider>
            </CardBody>
            <CardFooter>
              <div className="container-ccenter" style={{marginLeft:'300px'}}>
              <Button color="primary" onClick={handleclick}>Update Profile</Button>
              </div>
            </CardFooter>
          </Card>
          <br/>
        </GridItem>
        
        <GridItem xs={12} sm={12} md={4}>
          <Card profile>
            <CardAvatar profile>
              <a href="#pablo" onClick={e => e.preventDefault()}>
                <img src={avatar} alt="..." />
              </a>
            </CardAvatar>
            <CardBody profile>
              <h4 className={classes.cardTitle}>{fname} {lname}</h4>
              <br/>
              <h5 className={classes.cardTitle}>{email}</h5>
              <br/>
              <h5 className={classes.cardTitle}>{contact}</h5>
              <br/>
              <h5 className={classes.cardTitle}>{cnic}</h5>
              <br/>
              <h5 className={classes.cardTitle}>{address}</h5>
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    </div>
  );
}
