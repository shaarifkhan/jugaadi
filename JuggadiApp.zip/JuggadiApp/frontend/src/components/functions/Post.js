import React,{Component} from 'react';
import './hello.css';
import Dashbar from './../layout/Dashbar';
import {Redirect} from 'react-router-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import TextField from 'material-ui/TextField';
import { white } from 'material-ui/styles/colors';
class Dashboard extends Component{
	state={
		dashboard:false,
		post:false,
    want:false,
    wallet:false,
    profile:false,
    car:{
      carname:'',
      seats:'',
      departure:'',
      dtime:'',
      fare:'',
      route:''
    }

	}
	handledashboard=()=>{
		this.setState(()=>({
			dashboard:true
		}))
	}

	handlepost=()=>{
		this.setState(()=>({
			post:true
		}))
	}

	handlewant=()=>{
		this.setState(()=>({
			want:true
		}))
	}
  handlewallet=()=>{
		this.setState(()=>({
			wallet:true
		}))
  }
  handleprofile=()=>{
		this.setState(()=>({
			profile:true
		}))
	}
  handleclick=()=>{
    console.log(this.state.car)
  }
  render(){
    const {car}=this.state
    if(this.state.wallet===true)
		{
			return(
			<Redirect to='/wallet'/>
			)
		}
		if(this.state.dashboard===true)
		{
		    return(
			<Redirect to='/dashboard'/>
			)
		}
		if(this.state.want===true)
		{
			return(
			<Redirect to='/want'/>
			)
		}
		if(this.state.post===true)
		{
			return(
			<Redirect to='/post'/>
			)
    }
    if(this.state.profile===true)
		{
			return(
			<Redirect to='/Info'/>
			)
		}
 return(
             
<div >
    <Dashbar/>
    <MuiThemeProvider>
          <div>
          <AppBar
             title="Post a Ride" />
           </div>
           </MuiThemeProvider>
	<div className="grid-container">
        <aside className="sidenav" style={{'margin-bottom': 0,'padding-bottom':'1000'}} /* any large number will do */>
        <ul className="sidenav__list">
            <a onClick={this.handledashboard}> <li className="sidenav__list-item">Dashboard</li></a>
            <a onClick={this.handleprofile}><li className="sidenav__list-item">Profile</li></a>
            <a onClick={this.handlewant}><li className="sidenav__list-item">Want Ride</li></a>
            <a onClick={this.handlewallet}><li className="sidenav__list-item">Payment</li></a>
        </ul>
        </aside>
        </div>
    <div className="container-v">
        <form>
              <div className="row form-group">
              <div className="col-md-12 mb-3 mb-md-0">
                  <label className="font-weight-bold" htmlFor="fullname"><h3>Car Name</h3></label>
                  <input type="text" id="fullname"className="form-control" placeholder="eg. Civic, Alto, Corolla"
                  value={car.carname}
                  onChange={e => this.setState({ car: {...car, carname:e.target.value}})}/>
                </div>
              </div>
                <br></br>
              <div className="row form-group">
                <div className="col-md-12 mb-3 mb-md-0">
                  <label className="font-weight-bold" htmlFor="fullname"><h3>No of Seats Available</h3></label>
                  <input  type="number" id="fullname" className="form-control" placeholder="eg. 4 ,3 etc"
                  value={car.seats}
                  onChange={e => this.setState({ car: {...car, seats:e.target.value}})}/>
                </div>
              </div>
            <br></br>
              <div className="row form-group">
                <div className="col-md-12 mb-3 mb-md-0">
                  <label className="font-weight-bold" htmlFor="fullname"><h3>Departure Location</h3></label>
                  <input  type="location" id="fullname" className="form-control" placeholder="eg. Gulshan, Defense, Johar"
                  value={car.departure}
                  onChange={e => this.setState({ car: {...car, departure:e.target.value}})}/>
                </div>
              </div>
                <br/>
              <div className="row form-group">
                <div className="col-md-12 mb-3 mb-md-0">
                  <label className="font-weight-bold" htmlFor="fullname"><h3>Departure Time</h3></label>
                  <input  type="time" id="fullname" className="form-control" placeholder="eg. 3:00 PM, 12:00 PM, 10:00 AM "
                  value={car.dtime}
                  onChange={e => this.setState({ car: {...car, dtime:e.target.value}})}/>
                </div>
              </div>
              <br/>
              <div className="row form-group">
                <div className="col-md-12 mb-3 mb-md-0">
                  <label className="font-weight-bold" htmlFor="fullname"><h3>Fare in Rs</h3></label>
                  <input  type="number" id="fullname" className="form-control" placeholder="eg. 100, 200, 300"
                  value={car.fare}
                  onChange={e => this.setState({ car: {...car, fare:e.target.value}})}/>
                </div>
              </div>
              <br/>
              
              <div className="row form-group">
                <div className="col-md-12"><h3>Route Description</h3></div>
                <div className="col-md-12 mb-3 mb-md-0">
                  <textarea name="RouteDescription" className="form-control" id="" cols="30" rows="5"
                  value={car.route}
                  onChange={e => this.setState({ car: {...car, route:e.target.value}})}></textarea>
                </div>
              </div>
              <div className="row form-group">
                <div className="col-md-12">
                  <input onClick={this.handleclick} type="submit" value="Post"  className="btn btn-primary  py-2 px-5" style={{backgroundColor:'#00BCD4'}}/>
                </div>
              </div>
        </form>
        
   </div>
   </div>
)
}
}
export default Dashboard;       
