import React from 'react';
import Navbar from './../layout/Navbar';
const Ride =()=>{
    return(
        <div>
        <Navbar/>
        <div className="container-home">
            <h1  className="left" style={{float : 'left', paddingRight : '2px',color:'white',fontSize:50}}><b>Ride detaisl</b></h1>
        </div>
        </div>
    )
}
export default Ride;