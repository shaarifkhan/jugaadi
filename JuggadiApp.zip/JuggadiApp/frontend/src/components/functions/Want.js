import React,{Component} from 'react';
import './hello.css';
import Dashbar from './../layout/Dashbar';
import {Redirect} from 'react-router-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import Search from './Search';
class Dashboard extends Component{
	state={
		dashboard:false,
		post:false,
    want:false,
    wallet:false,
    profile:false,
    user:{
      name:'',
      carname:'',
      seats:'',
      contact:'',
      departure:''
    }
  }
  handleget=(props)=>{
    this.state.user.name=this.props.name,
    this.state.user.carname=this.props.carname,
    this.state.user.seats=this.props.seats,
    this.state.user.contact=this.props.contact,
    this.state.user.departure=this.props.departure
  }
	handledashboard=()=>{
		this.setState(()=>({
			dashboard:true
		}))
	}

	handlepost=()=>{
		this.setState(()=>({
			post:true
		}))
	}

	handlewant=()=>{
		this.setState(()=>({
			want:true
		}))
	}
  handlewallet=()=>{
		this.setState(()=>({
			wallet:true
		}))
  }
  handleprofile=()=>{
		this.setState(()=>({
			profile:true
		}))
	}
  render(){
		if(this.state.dashboard===true)
		{
		    return(
			<Redirect to='/dashboard'/>
			)
		}
		if(this.state.want===true)
		{
			return(
			<Redirect to='/want'/>
			)
		}
		if(this.state.post===true)
		{
			return(
			<Redirect to='/post'/>
			)
    }
    if(this.state.wallet===true)
		{
			return(
			<Redirect to='/wallet'/>
			)
    }
    if(this.state.profile===true)
		{
			return(
			<Redirect to='/Info'/>
			)
		}
 return(
        
<div >
    <Dashbar/>
    <Search/>
	      <div class="grid-container">
        <aside class="sidenav-b">
        <ul class="sidenav__list">
            <a onClick={this.handledashboard}> <li class="sidenav__list-item">Dashboard</li></a>
            <a onClick={this.handleprofile}><li class="sidenav__list-item">Profile</li></a>
            <a onClick={this.handlepost}><li class="sidenav__list-item">Post Ride</li></a>
            <a onClick={this.handlewallet}><li class="sidenav__list-item">Payment</li></a>
        </ul>
        </aside>
        </div>
        
        <div class="grid-container-b">
        <aside class="sidenav-b">
            <div className="container-n">
            <h1 class="sidenav__list-item"> Notifications</h1>
            </div>
        </aside>
        </div>
        <div className="container-bcenter">
        <br/>
         
          <div className="row form-group">
              <div className="col-md-12 mb-3 mb-md-0">
                <br></br>
                  <label className="font-weight-bold" htmlFor="fullname"><h3></h3></label>
                  <h3>{this.state.user.name}</h3>
                </div>
              </div>
              <br/>

              <div className="row form-group">
              <div className="col-md-12 mb-3 mb-md-0">
                <br></br>
                  <label className="font-weight-bold" htmlFor="fullname"><h3></h3></label>
                  <h3>{this.state.user.carname}</h3>

                </div>
              </div>
              <br/>

              <div className="row form-group">
              <div className="col-md-12 mb-3 mb-md-0">
                <br></br>
                  <label className="font-weight-bold" htmlFor="fullname"><h3></h3></label>
                  <h3>{this.state.user.seats}</h3>

                </div>
              </div>
              <br/>

              <div className="row form-group">
              <div className="col-md-12 mb-3 mb-md-0">
                <br></br>
                  <label className="font-weight-bold" htmlFor="fullname"><h3></h3></label>
                  <h3>{this.state.user.contact}</h3>
                </div>
              </div>
              <br/>

              <div className="row form-group">
              <div className="col-md-12 mb-3 mb-md-0">
                <br></br>
                  <label className="font-weight-bold" htmlFor="fullname"><h3></h3></label>
                  <h3>{this.state.user.departure}</h3>
                </div>
              </div>
              <br/>
      </div>
      </div>
    
    
)
}
}
export default Dashboard;       