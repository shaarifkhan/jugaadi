import React,{Component} from 'react';
import './hello.css';
import Dashbar from './../layout/Dashbar';
import {Redirect} from 'react-router-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import TextField from 'material-ui/TextField';
import { white } from 'material-ui/styles/colors';
import Wallet from './Wallet';
class Dashboard extends Component{
	state={
		dashboard:false,
		post:false,
        want:false,
        profile:false
	}
	handledashboard=()=>{
		this.setState(()=>({
			dashboard:true
		}))
	}

	handlepost=()=>{
		this.setState(()=>({
			post:true
		}))
	}

	handlewant=()=>{
		this.setState(()=>({
			want:true
		}))
	}
  handleprofile=()=>{
		this.setState(()=>({
			profile:true
		}))
	}
  render(){
    if(this.state.profile===true)
		{
			return(
			<Redirect to='/Info'/>
			)
		}
		if(this.state.dashboard===true)
		{
		    return(
			<Redirect to='/dashboard'/>
			)
		}
		if(this.state.want===true)
		{
			return(
			<Redirect to='/want'/>
			)
		}
		if(this.state.post===true)
		{
			return(
			<Redirect to='/post'/>
			)
        }
 return(
        <div >
    <Dashbar/>
    <MuiThemeProvider>
          <div>
          <AppBar
             title="Payment" />
           </div>
           </MuiThemeProvider>
	<div className="grid-container">
        <aside className="sidenav" style={{'margin-bottom': 0,'padding-bottom':0}} /* any large number will do */>
        <ul class="sidenav__list">
            <a onClick={this.handledashboard}> <li class="sidenav__list-item">Dashboard</li></a>
            <a onClick={this.handleprofile}><li class="sidenav__list-item">Profile</li></a>
            <a onClick={this.handlewant}><li class="sidenav__list-item">Want Ride</li></a>
            <a onClick={this.handlepost}><li class="sidenav__list-item">Post Ride</li></a>
        </ul>
        </aside>
        </div>
            <Wallet/>
	</div>

)
}
}
export default Dashboard;       
