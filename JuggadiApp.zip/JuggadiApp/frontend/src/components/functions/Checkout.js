import React,{ useState } from 'react';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

export default function PaymentForm() {
  const [cname,setCname] = useState(" ");
  const [cno,setCno] = useState("");
	const [exp,setExp] = useState("");
  const [cvv,setCvv] = useState("");
  const state={cname,cno,exp,cvv};
  const handleClick=()=>{
    console.log(state);
  }
  return (
    <React.Fragment>
      <Typography variant="h4" gutterbottom>
        Payment Details
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <TextField required id="cardName" label="Name on card" fullWidth
          value={cname}
          onChange={e => setCname(e.target.value)}
           />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField required id="cardNumber" label="Card number" fullWidth
          value={cno}
          onChange={e => setCno(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField required id="expDate" label="Expiry date" fullWidth
          value={exp}
          onChange={e => setExp(e.target.value)}
           />
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            required
            id="cvv"
            label="CVV"
            helperText="Last three digits on signature strip"
            fullWidth
            value={cvv}
            onChange={e => setCvv(e.target.value)}
          />
        </Grid>
        <Grid item xs={12}>
          <FormControlLabel
            onClick={handleClick}
            control={<Checkbox color="primary" name="saveCard" value="yes" />}
            label="Remember credit card details for next time"
          />
        </Grid>
      </Grid>
    </React.Fragment>
  );
}