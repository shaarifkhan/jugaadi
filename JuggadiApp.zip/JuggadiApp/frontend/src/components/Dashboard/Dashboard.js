import React,{Component} from 'react';
import './hello.css';
import Dashbar from './../layout/Dashbar';
import {Redirect} from 'react-router-dom'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import Mapping from './../currentlocation/Mapcontainer';
import Smap from './simplemap';
class Dashboard extends Component{
	state={
		info:false,
		post:false,
		want:false,
		ride:false,
		wallet:false,
		name:'fawaz',
		departure:'johar',
		contact:'0331-0350398'
	}
	handleinfo=()=>{
		console.log('ayrein')
		this.setState(()=>({
			info:true
		}))
	}

	handlepost=()=>{
		this.setState(()=>({
			post:true
		}))
	}
	handlewallet=()=>{
		this.setState(()=>({
			wallet:true
		}))
	}
	handleride=()=>{
		this.setState(()=>({
			ride:true
		}))
	}

	handlewant=()=>{
		this.setState(()=>({
			want:true
		}))
	}

  render(){
		if(this.state.info===true)
		{
		    return(
			<Redirect to='/Info'/>
			)
		}
		if(this.state.want===true)
		{
			return(
			<Redirect to='/want'/>
			)
		}
		if(this.state.post===true)
		{
			return(
			<Redirect to='/post'/>
			)
		}
		if(this.state.ride===true)
		{
			return(
			<Redirect to='/ride'/>
			)
		}
		if(this.state.wallet===true)
		{
			return(
			<Redirect to='/wallet'/>
			)
		}
		
return(
        
<div >
    <Dashbar/>
    <MuiThemeProvider>
          <div>
          <AppBar
             title="Welcome Mr. Ansari"/>
           </div>
           </MuiThemeProvider>
	<div class="grid-container">
        <aside class="sidenav-b">
        <ul class="sidenav__list">
        <a onClick={this.handleinfo}><li class="sidenav__list-item">Profile</li></a>
            <a onClick={this.handlepost}><li class="sidenav__list-item">Post Ride</li></a>
            <a onClick={this.handlewant}><li class="sidenav__list-item">Want Ride</li></a>
			<a onClick={this.handlewallet}><li class="sidenav__list-item">Payment</li></a>
        </ul>
        </aside>
    </div>
    <div className="container-ccenter">
    <Mapping/>
    </div>
    <div class="grid-container-b">
        <aside class="sidenav-b">
            <div className="container-n">
            <h1 class="sidenav__list-item"> Notifications</h1>
            </div>
			<ul class="sidenav__list">
        <a onClick={this.handleride}><li class="sidenav__list-item">Fawaz Ansari posted a new ride <br/>from Johar to Fast </li></a>
        </ul>
        </aside>
    </div>
</div>
)
}
}
export default Dashboard;
