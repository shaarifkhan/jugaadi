import React from 'react';
import Dashbar from './../layout/Dashbar';
import Dashboard from './../Dashboard/Dashboard';
const FHome =()=>{
    return(
        <div>
        <Dashboard/>
        </div>
        
    )
}
export default FHome;