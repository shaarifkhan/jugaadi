import React from 'react';
import Navbar from './../layout/Navbar';
import Login from './../Auth/Signin';
const JHome =()=>{
    return(
        <div>
        <Navbar/>
        <div className="container-home">
            <h1  className="left" style={{float : 'left', paddingRight : '2px',color:'white',fontSize:50}}><b>Earn and Ride<br></br>with Jo Gaadi.</b></h1>
        </div>
        <div className="container-right">
            
        </div>
            
        </div>
    )
}
export default JHome;