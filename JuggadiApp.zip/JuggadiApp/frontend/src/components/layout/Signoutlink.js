import React from 'react';
import { NavLink as Link } from 'react-router-dom';
const Signoutlink =()=>{
    return(
    <div >
        <Link to= '/Signup' className="navbar-brand"> Signup </Link>
        <Link to= '/Signin' className="navbar-brand"> Log in </Link>
    </div>
    )
}
export default Signoutlink;