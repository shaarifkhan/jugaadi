import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Signinlink from "./Signinlink";
import Signoutlink from "./Signoutlink";

class Navbar extends Component{
    handlelogin=()=>{
        console.log(this.props.done)
    }
    
    
    render()
    {
        return(
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                <div className="container"  >
                    <div className="left">
                    <Link to ='/' className="brand-logo" className="navbar-brand" > J0 GAADI </Link>
                    </div>
                    <Signoutlink/>
                </div>
            </nav>
            )
        }
}
export default Navbar