import React from 'react';
import { Link } from 'react-router-dom';
import Dashlink from './Dashlink';
import Signinlink from './Signinlink';
const Dashbar =(props)=>{
        return(
            
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark" >
                <div className="container"  >
                    <div className="left">
                    <Link to ='/' className="brand-logo" className="navbar-brand" > J0 GAADI </Link>
                    </div>
                    <Signinlink/>
                    
                </div>
            </nav>
            )
}
export default Dashbar;