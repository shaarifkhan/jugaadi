import React from 'react';
import { Link } from 'react-router-dom';

const Signinlink =()=>{
    return(
    <div >
        <Link to= '/'className="navbar-brand"> Log out </Link>
    </div>
    )
}
export default Signinlink;