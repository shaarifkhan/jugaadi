import React from 'react';
import { Link } from 'react-router-dom';

const Dashlink =()=>{
    return(
    <div >
        <Link to= '/post'className="navbar-brand"> Post Ride </Link>
        <Link to= '/want'className="navbar-brand"> Want Ride </Link>
        <Link to= '/wallet'className="navbar-brand"> Payment </Link>
    </div>
    )
}
export default Dashlink;